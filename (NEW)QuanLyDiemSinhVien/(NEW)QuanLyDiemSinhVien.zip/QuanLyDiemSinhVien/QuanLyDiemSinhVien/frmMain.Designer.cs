﻿namespace QuanLyDiemSinhVien
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đầuSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.độcGiảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinMượnTrảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinTácGiảToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.điểmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinTácGiảToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.hướngDẫnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.đầuSáchToolStripMenuItem,
            this.độcGiảToolStripMenuItem,
            this.thôngTinMượnTrảToolStripMenuItem,
            this.thôngTinTácGiảToolStripMenuItem1,
            this.điểmToolStripMenuItem,
            this.trợGiúpToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(786, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thoátToolStripMenuItem});
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.hệThốngToolStripMenuItem.Text = "Hệ thống";
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.thoátToolStripMenuItem.Text = "Thoát";
            this.thoátToolStripMenuItem.Click += new System.EventHandler(this.thoátToolStripMenuItem_Click);
            // 
            // đầuSáchToolStripMenuItem
            // 
            this.đầuSáchToolStripMenuItem.Name = "đầuSáchToolStripMenuItem";
            this.đầuSáchToolStripMenuItem.Size = new System.Drawing.Size(104, 20);
            this.đầuSáchToolStripMenuItem.Text = "Danh Mục Khoa";
            this.đầuSáchToolStripMenuItem.Click += new System.EventHandler(this.đầuSáchToolStripMenuItem_Click);
            // 
            // độcGiảToolStripMenuItem
            // 
            this.độcGiảToolStripMenuItem.Name = "độcGiảToolStripMenuItem";
            this.độcGiảToolStripMenuItem.Size = new System.Drawing.Size(97, 20);
            this.độcGiảToolStripMenuItem.Text = "Danh Mục Lớp";
            this.độcGiảToolStripMenuItem.Click += new System.EventHandler(this.độcGiảToolStripMenuItem_Click);
            // 
            // thôngTinMượnTrảToolStripMenuItem
            // 
            this.thôngTinMượnTrảToolStripMenuItem.Name = "thôngTinMượnTrảToolStripMenuItem";
            this.thôngTinMượnTrảToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.thôngTinMượnTrảToolStripMenuItem.Text = "Sinh Viên";
            this.thôngTinMượnTrảToolStripMenuItem.Click += new System.EventHandler(this.thôngTinMượnTrảToolStripMenuItem_Click);
            // 
            // thôngTinTácGiảToolStripMenuItem1
            // 
            this.thôngTinTácGiảToolStripMenuItem1.Name = "thôngTinTácGiảToolStripMenuItem1";
            this.thôngTinTácGiảToolStripMenuItem1.Size = new System.Drawing.Size(128, 20);
            this.thôngTinTácGiảToolStripMenuItem1.Text = "Danh Sách Môn Học";
            this.thôngTinTácGiảToolStripMenuItem1.Click += new System.EventHandler(this.thôngTinTácGiảToolStripMenuItem1_Click);
            // 
            // điểmToolStripMenuItem
            // 
            this.điểmToolStripMenuItem.Name = "điểmToolStripMenuItem";
            this.điểmToolStripMenuItem.Size = new System.Drawing.Size(105, 20);
            this.điểmToolStripMenuItem.Text = "Danh Mục Điểm";
            this.điểmToolStripMenuItem.Click += new System.EventHandler(this.điểmToolStripMenuItem_Click);
            // 
            // trợGiúpToolStripMenuItem1
            // 
            this.trợGiúpToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinTácGiảToolStripMenuItem2,
            this.hướngDẫnToolStripMenuItem1});
            this.trợGiúpToolStripMenuItem1.Name = "trợGiúpToolStripMenuItem1";
            this.trợGiúpToolStripMenuItem1.Size = new System.Drawing.Size(64, 20);
            this.trợGiúpToolStripMenuItem1.Text = "Trợ Giúp";
            // 
            // thôngTinTácGiảToolStripMenuItem2
            // 
            this.thôngTinTácGiảToolStripMenuItem2.Name = "thôngTinTácGiảToolStripMenuItem2";
            this.thôngTinTácGiảToolStripMenuItem2.Size = new System.Drawing.Size(164, 22);
            this.thôngTinTácGiảToolStripMenuItem2.Text = "Thông tin tác giả";
            // 
            // hướngDẫnToolStripMenuItem1
            // 
            this.hướngDẫnToolStripMenuItem1.Name = "hướngDẫnToolStripMenuItem1";
            this.hướngDẫnToolStripMenuItem1.Size = new System.Drawing.Size(164, 22);
            this.hướngDẫnToolStripMenuItem1.Text = "Hướng dẫn";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 438);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(786, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(156, 17);
            this.toolStripStatusLabel1.Text = "Bản quyền thuộc về nhóm 4";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 460);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "frmMain";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đầuSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem độcGiảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinMượnTrảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinTácGiảToolStripMenuItem1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem điểmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinTácGiảToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem hướngDẫnToolStripMenuItem1;
    }
}

