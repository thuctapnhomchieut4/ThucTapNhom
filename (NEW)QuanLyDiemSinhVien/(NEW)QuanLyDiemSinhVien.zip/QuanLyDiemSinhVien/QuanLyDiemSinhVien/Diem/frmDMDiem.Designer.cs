﻿namespace QuanLyDiemSinhVien
{
    partial class frmDMDiem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDMDiem));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tvDMDiem = new System.Windows.Forms.TreeView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.phânLoạiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.điểm9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.điểm9ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.điểm85ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.điểm8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.điểm7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.từCaoThấpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.từThấpCaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quaTrượtMônToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quaMônToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trượtMônToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.txtMaMH = new System.Windows.Forms.TextBox();
            this.txtLanThi = new System.Windows.Forms.TextBox();
            this.txtMaSV = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDiemSo = new System.Windows.Forms.TextBox();
            this.txtDiemChu = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.MaSV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaMH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LanThi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiemSo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiemChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.txtTimKiemDiem = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.thốngKêToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tvDMDiem);
            this.groupBox2.Controls.Add(this.menuStrip1);
            this.groupBox2.Location = new System.Drawing.Point(16, 53);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 234);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            // 
            // tvDMDiem
            // 
            this.tvDMDiem.Location = new System.Drawing.Point(18, 43);
            this.tvDMDiem.Name = "tvDMDiem";
            this.tvDMDiem.Size = new System.Drawing.Size(176, 180);
            this.tvDMDiem.TabIndex = 15;
            this.tvDMDiem.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvDMDiem_AfterSelect);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.phânLoạiToolStripMenuItem,
            this.quaTrượtMônToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(3, 16);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(194, 24);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // phânLoạiToolStripMenuItem
            // 
            this.phânLoạiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.điểm9ToolStripMenuItem,
            this.điểm9ToolStripMenuItem1,
            this.điểm85ToolStripMenuItem,
            this.điểm8ToolStripMenuItem,
            this.điểm7ToolStripMenuItem,
            this.tấtCảToolStripMenuItem,
            this.từCaoThấpToolStripMenuItem,
            this.từThấpCaoToolStripMenuItem});
            this.phânLoạiToolStripMenuItem.Name = "phânLoạiToolStripMenuItem";
            this.phânLoạiToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.phânLoạiToolStripMenuItem.Text = "Phân Loại";
            // 
            // điểm9ToolStripMenuItem
            // 
            this.điểm9ToolStripMenuItem.Name = "điểm9ToolStripMenuItem";
            this.điểm9ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.điểm9ToolStripMenuItem.Text = "Điểm >=9";
            this.điểm9ToolStripMenuItem.Click += new System.EventHandler(this.điểm9ToolStripMenuItem_Click);
            // 
            // điểm9ToolStripMenuItem1
            // 
            this.điểm9ToolStripMenuItem1.Name = "điểm9ToolStripMenuItem1";
            this.điểm9ToolStripMenuItem1.Size = new System.Drawing.Size(158, 22);
            this.điểm9ToolStripMenuItem1.Text = "8 <= Điểm <9";
            this.điểm9ToolStripMenuItem1.Click += new System.EventHandler(this.điểm9ToolStripMenuItem1_Click);
            // 
            // điểm85ToolStripMenuItem
            // 
            this.điểm85ToolStripMenuItem.Name = "điểm85ToolStripMenuItem";
            this.điểm85ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.điểm85ToolStripMenuItem.Text = "7 <= Điểm <8";
            this.điểm85ToolStripMenuItem.Click += new System.EventHandler(this.điểm85ToolStripMenuItem_Click);
            // 
            // điểm8ToolStripMenuItem
            // 
            this.điểm8ToolStripMenuItem.Name = "điểm8ToolStripMenuItem";
            this.điểm8ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.điểm8ToolStripMenuItem.Text = "4 <= Điểm <7";
            this.điểm8ToolStripMenuItem.Click += new System.EventHandler(this.điểm8ToolStripMenuItem_Click);
            // 
            // điểm7ToolStripMenuItem
            // 
            this.điểm7ToolStripMenuItem.Name = "điểm7ToolStripMenuItem";
            this.điểm7ToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.điểm7ToolStripMenuItem.Text = "4 < Điểm";
            this.điểm7ToolStripMenuItem.Click += new System.EventHandler(this.điểm7ToolStripMenuItem_Click);
            // 
            // tấtCảToolStripMenuItem
            // 
            this.tấtCảToolStripMenuItem.Name = "tấtCảToolStripMenuItem";
            this.tấtCảToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.tấtCảToolStripMenuItem.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem.Click += new System.EventHandler(this.tấtCảToolStripMenuItem_Click);
            // 
            // từCaoThấpToolStripMenuItem
            // 
            this.từCaoThấpToolStripMenuItem.Name = "từCaoThấpToolStripMenuItem";
            this.từCaoThấpToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.từCaoThấpToolStripMenuItem.Text = "Từ Cao -> Thấp";
            this.từCaoThấpToolStripMenuItem.Click += new System.EventHandler(this.từCaoThấpToolStripMenuItem_Click);
            // 
            // từThấpCaoToolStripMenuItem
            // 
            this.từThấpCaoToolStripMenuItem.Name = "từThấpCaoToolStripMenuItem";
            this.từThấpCaoToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.từThấpCaoToolStripMenuItem.Text = "Từ Thấp -> Cao";
            this.từThấpCaoToolStripMenuItem.Click += new System.EventHandler(this.từThấpCaoToolStripMenuItem_Click);
            // 
            // quaTrượtMônToolStripMenuItem
            // 
            this.quaTrượtMônToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quaMônToolStripMenuItem,
            this.trượtMônToolStripMenuItem,
            this.tấtCảToolStripMenuItem1,
            this.thốngKêToolStripMenuItem});
            this.quaTrượtMônToolStripMenuItem.Name = "quaTrượtMônToolStripMenuItem";
            this.quaTrượtMônToolStripMenuItem.Size = new System.Drawing.Size(108, 20);
            this.quaTrượtMônToolStripMenuItem.Text = "Qua / Trượt Môn";
            // 
            // quaMônToolStripMenuItem
            // 
            this.quaMônToolStripMenuItem.Name = "quaMônToolStripMenuItem";
            this.quaMônToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.quaMônToolStripMenuItem.Text = "Qua Môn";
            this.quaMônToolStripMenuItem.Click += new System.EventHandler(this.quaMônToolStripMenuItem_Click);
            // 
            // trượtMônToolStripMenuItem
            // 
            this.trượtMônToolStripMenuItem.Name = "trượtMônToolStripMenuItem";
            this.trượtMônToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.trượtMônToolStripMenuItem.Text = "Trượt Môn";
            this.trượtMônToolStripMenuItem.Click += new System.EventHandler(this.trượtMônToolStripMenuItem_Click);
            // 
            // tấtCảToolStripMenuItem1
            // 
            this.tấtCảToolStripMenuItem1.Name = "tấtCảToolStripMenuItem1";
            this.tấtCảToolStripMenuItem1.Size = new System.Drawing.Size(153, 22);
            this.tấtCảToolStripMenuItem1.Text = "Xem Tất Cả";
            this.tấtCảToolStripMenuItem1.Click += new System.EventHandler(this.tấtCảToolStripMenuItem1_Click);
            // 
            // txtMaMH
            // 
            this.txtMaMH.Location = new System.Drawing.Point(103, 114);
            this.txtMaMH.Name = "txtMaMH";
            this.txtMaMH.Size = new System.Drawing.Size(403, 20);
            this.txtMaMH.TabIndex = 14;
            // 
            // txtLanThi
            // 
            this.txtLanThi.Location = new System.Drawing.Point(103, 140);
            this.txtLanThi.Name = "txtLanThi";
            this.txtLanThi.Size = new System.Drawing.Size(403, 20);
            this.txtLanThi.TabIndex = 13;
            // 
            // txtMaSV
            // 
            this.txtMaSV.Location = new System.Drawing.Point(103, 88);
            this.txtMaSV.Name = "txtMaSV";
            this.txtMaSV.Size = new System.Drawing.Size(403, 20);
            this.txtMaSV.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Mã Môn Học";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(54, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Lần Thi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Mã Sinh Viên";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(230, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 31);
            this.label2.TabIndex = 7;
            this.label2.Text = "ĐIỂM THI";
            // 
            // txtDiemSo
            // 
            this.txtDiemSo.Location = new System.Drawing.Point(103, 166);
            this.txtDiemSo.Name = "txtDiemSo";
            this.txtDiemSo.Size = new System.Drawing.Size(403, 20);
            this.txtDiemSo.TabIndex = 19;
            // 
            // txtDiemChu
            // 
            this.txtDiemChu.Location = new System.Drawing.Point(103, 192);
            this.txtDiemChu.Name = "txtDiemChu";
            this.txtDiemChu.Size = new System.Drawing.Size(403, 20);
            this.txtDiemChu.TabIndex = 18;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(50, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Điểm Số";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 195);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Điểm Chữ";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.dataGridView4);
            this.groupBox1.Controls.Add(this.txtDiemSo);
            this.groupBox1.Controls.Add(this.txtDiemChu);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtMaMH);
            this.groupBox1.Controls.Add(this.txtLanThi);
            this.groupBox1.Controls.Add(this.txtMaSV);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(237, 48);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(617, 566);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.AllowUserToDeleteRows = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaSV,
            this.MaMH,
            this.LanThi,
            this.DiemSo,
            this.DiemChu});
            this.dataGridView4.Location = new System.Drawing.Point(15, 235);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.Size = new System.Drawing.Size(582, 322);
            this.dataGridView4.TabIndex = 23;
            this.dataGridView4.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellClick);
            // 
            // MaSV
            // 
            this.MaSV.DataPropertyName = "MaSV";
            this.MaSV.HeaderText = "Mã Sinh Viên";
            this.MaSV.Name = "MaSV";
            this.MaSV.ReadOnly = true;
            this.MaSV.Width = 140;
            // 
            // MaMH
            // 
            this.MaMH.DataPropertyName = "MaMH";
            this.MaMH.HeaderText = "Mã Môn Học";
            this.MaMH.Name = "MaMH";
            this.MaMH.ReadOnly = true;
            // 
            // LanThi
            // 
            this.LanThi.DataPropertyName = "LanThi";
            this.LanThi.HeaderText = "Lần Thi";
            this.LanThi.Name = "LanThi";
            this.LanThi.ReadOnly = true;
            // 
            // DiemSo
            // 
            this.DiemSo.DataPropertyName = "DiemSo";
            this.DiemSo.HeaderText = "Điểm Số";
            this.DiemSo.Name = "DiemSo";
            this.DiemSo.ReadOnly = true;
            // 
            // DiemChu
            // 
            this.DiemChu.DataPropertyName = "DiemChu";
            this.DiemChu.HeaderText = "Điểm Chữ";
            this.DiemChu.Name = "DiemChu";
            this.DiemChu.ReadOnly = true;
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(58, 22);
            this.toolStripButton5.Text = "Thoát";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(47, 22);
            this.toolStripButton3.Text = "Xóa";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(46, 22);
            this.toolStripButton2.Text = "Sửa";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(82, 22);
            this.toolStripButton1.Text = "Thêm mới";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton5});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(876, 25);
            this.toolStrip1.TabIndex = 17;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.Location = new System.Drawing.Point(141, 396);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(75, 23);
            this.btnTimKiem.TabIndex = 20;
            this.btnTimKiem.Text = "Tìm Kiếm";
            this.btnTimKiem.UseVisualStyleBackColor = true;
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);
            // 
            // txtTimKiemDiem
            // 
            this.txtTimKiemDiem.Location = new System.Drawing.Point(85, 360);
            this.txtTimKiemDiem.Name = "txtTimKiemDiem";
            this.txtTimKiemDiem.Size = new System.Drawing.Size(131, 20);
            this.txtTimKiemDiem.TabIndex = 21;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 363);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "Tìm Kiếm";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(43, 313);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(142, 31);
            this.label8.TabIndex = 20;
            this.label8.Text = "TÌM KIẾM";
            // 
            // thốngKêToolStripMenuItem
            // 
            this.thốngKêToolStripMenuItem.Name = "thốngKêToolStripMenuItem";
            this.thốngKêToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.thốngKêToolStripMenuItem.Text = "Thống Kê Tỉ Lệ";
            this.thốngKêToolStripMenuItem.Click += new System.EventHandler(this.thốngKêToolStripMenuItem_Click);
            // 
            // frmDMDiem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(876, 617);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtTimKiemDiem);
            this.Controls.Add(this.btnTimKiem);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "frmDMDiem";
            this.Text = "frmDMDiem";
            this.Load += new System.EventHandler(this.frmDMDiem_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TreeView tvDMDiem;
        private System.Windows.Forms.TextBox txtMaMH;
        private System.Windows.Forms.TextBox txtLanThi;
        private System.Windows.Forms.TextBox txtMaSV;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDiemSo;
        private System.Windows.Forms.TextBox txtDiemChu;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem phânLoạiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem điểm9ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem điểm9ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem điểm85ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem điểm8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem điểm7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quaTrượtMônToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quaMônToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trượtMônToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem1;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.TextBox txtTimKiemDiem;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaSV;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaMH;
        private System.Windows.Forms.DataGridViewTextBoxColumn LanThi;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiemSo;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiemChu;
        private System.Windows.Forms.ToolStripMenuItem từCaoThấpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem từThấpCaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thốngKêToolStripMenuItem;
    }
}